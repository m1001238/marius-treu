var class_s_q_l =
[
    [ "SQL", "class_s_q_l.html#a6c9eb70e74269d923dd578392153dc73", null ],
    [ "~SQL", "class_s_q_l.html#a1c65a40213ae07fdd8f25bd292b2a68c", null ],
    [ "insertIntoDB", "class_s_q_l.html#a887c01db09d7b4358a1965008305343d", null ],
    [ "selectOutOfDB", "class_s_q_l.html#a5d36a7b54983267bde65179fdfbb066b", null ]
];