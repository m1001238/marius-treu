var files =
[
    [ "Bot.h", null, null ],
    [ "Connect.h", null, null ],
    [ "Database.h", null, null ],
    [ "SQL.h", null, null ],
    [ "Utilities.h", null, null ]
];