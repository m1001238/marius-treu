var NAVTREEINDEX =
{
"index.html":[],
"annotated.html":[0,0],
"classprogramm_1_1_bot.html":[0,0,0],
"classutilities_1_1_char_extend.html":[0,0,1],
"classprogramm_1_1_connect.html":[0,0,2],
"classprogramm_1_1_database.html":[0,0,3],
"classutilities_1_1_interpreted_buffer.html":[0,0,4],
"class_s_q_l.html":[0,0,5],
"classutilities_1_1_time_tools.html":[0,0,6],
"classes.html":[0,1],
"functions.html":[0,2,0],
"functions_func.html":[0,2,1],
"files.html":[1,0]
};
