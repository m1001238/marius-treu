var annotated =
[
    [ "programm::Bot", "classprogramm_1_1_bot.html", "classprogramm_1_1_bot" ],
    [ "utilities::CharExtend", "classutilities_1_1_char_extend.html", "classutilities_1_1_char_extend" ],
    [ "programm::Connect", "classprogramm_1_1_connect.html", "classprogramm_1_1_connect" ],
    [ "programm::Database", "classprogramm_1_1_database.html", "classprogramm_1_1_database" ],
    [ "utilities::InterpretedBuffer", "classutilities_1_1_interpreted_buffer.html", "classutilities_1_1_interpreted_buffer" ],
    [ "SQL", "class_s_q_l.html", "class_s_q_l" ],
    [ "utilities::TimeTools", "classutilities_1_1_time_tools.html", "classutilities_1_1_time_tools" ]
];