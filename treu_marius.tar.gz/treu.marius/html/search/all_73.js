var searchData=
[
  ['sql',['SQL',['../class_s_q_l.html',1,'']]]
];
