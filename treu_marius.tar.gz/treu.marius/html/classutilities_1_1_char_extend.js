var classutilities_1_1_char_extend =
[
    [ "makeSmall", "classutilities_1_1_char_extend.html#acd0755f094e805bd77389b4efd0f7ef4", null ]
];