var classprogramm_1_1_connect =
[
    [ "Connect", "classprogramm_1_1_connect.html#a7053125ff50def421f2344062b44d5d7", null ],
    [ "~Connect", "classprogramm_1_1_connect.html#a430385b9c1825aaa2eccd95cd8e83daa", null ],
    [ "getBotname", "classprogramm_1_1_connect.html#a2f482d2914eddae0b4cb9294f1a8a27c", null ],
    [ "getChannel", "classprogramm_1_1_connect.html#ad71ab1cf7e351225779abaef8f0ef5da", null ],
    [ "ping_parse", "classprogramm_1_1_connect.html#af000d58344d858db7042ecc05ab2c11a", null ],
    [ "run", "classprogramm_1_1_connect.html#a3f4b6b21e9cb516cbcec354f64e811c8", null ],
    [ "s2u", "classprogramm_1_1_connect.html#ab3cee879c5594b1f6252d42180d17eb0", null ],
    [ "setBotname", "classprogramm_1_1_connect.html#ac6f794325af90bec71cf68169d933be0", null ]
];