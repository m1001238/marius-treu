var classutilities_1_1_interpreted_buffer =
[
    [ "InterpretedBuffer", "classutilities_1_1_interpreted_buffer.html#adea092f85f0d41b852f717cbf2fecef0", null ],
    [ "atPosition", "classutilities_1_1_interpreted_buffer.html#a575048c82d8206e94cd95acb0ada0483", null ],
    [ "message", "classutilities_1_1_interpreted_buffer.html#a6ad2952aaad258f5fd66556ca64feaf6", null ],
    [ "sender", "classutilities_1_1_interpreted_buffer.html#afa28b61107dccba01eafc169379773f1", null ]
];