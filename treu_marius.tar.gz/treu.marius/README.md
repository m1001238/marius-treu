##IRC-BOT##

 Bot - IRC Bot, der eine Verbindung mit einem IRC-server aufbaut
        

##SYNOPSIS

 ./main server port channel

##DESCRIPTION

- Dieser Bot starten eine Verbindung zwischen Client und Server. <br />
- server, port und channel werden zum Start übergeben. <br />
- Mit nick und channel wird identifiziert. <br />

 Der Bot arbeitet mit folgenden Meldungen: <br />

##OPTIONS

- -o - um anzuzeigen welche features möglich sind <br />
- -cn name - um den Namen des Bots zu ändern <br />
- -log on/off - um das Logging ein-/auszuschalten <br />
- -last name - um zu sehen wann welcher Nutzer zuletzt etwas getan hat <br />
- -join channel - um den Bot einen channel beitreten zu lassen <br />
- -leave channel - um den Bot einen channel verlassen zu lassen <br />
- -topic channel text - um das Topic in einem channel zu ändern <br />
- -curtime - um die momentane Zeit anzuzeigen <br />
- -love name1 name2 - teste ob du und dein Schwarm zusammen passen - cooles Feature ;-) <br />
- -shutdown - um den Bot herunterfahren zu lassen <br />
 
##AUTHOR
 Marius Treu m1001238.fh-heidelberg.de
